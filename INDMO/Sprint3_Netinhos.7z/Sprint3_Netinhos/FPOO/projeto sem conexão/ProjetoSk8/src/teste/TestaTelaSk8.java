package teste;

import telas.TelaSk8;

public class TestaTelaSk8 {
    public static void main(String[] args) {
        TelaSk8 telaSk8 = new TelaSk8("Tela de Cadastro Sk8 Toony");
        telaSk8.setVisible(true);
    }
}